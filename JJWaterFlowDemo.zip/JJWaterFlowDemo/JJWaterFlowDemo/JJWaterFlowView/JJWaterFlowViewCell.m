//
//  JJWaterFlowViewCell.m
//  JJWaterFlowDemo
//
//  Created by 吉祥 on 2017/5/23.
//  Copyright © 2017年 jixiang. All rights reserved.
//

#import "JJWaterFlowViewCell.h"

@implementation JJWaterFlowViewCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
