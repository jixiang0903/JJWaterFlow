//
//  AppDelegate.h
//  JJWaterFlowDemo
//
//  Created by 吉祥 on 2017/5/23.
//  Copyright © 2017年 jixiang. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

